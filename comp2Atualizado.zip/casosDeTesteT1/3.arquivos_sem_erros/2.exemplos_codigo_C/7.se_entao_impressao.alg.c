/*
  Comando 'se' com impressao
  Helena Caseli
  2010
*/

#include <stdio.h>
#include <stdlib.h>

int main() {
	if (4 > 3) {
		printf("4 eh maior do que 3");
	}
	return 0;
}
