/*
  Declaracao de uma variavel do tipo inteiro, leitura e impressao de seu valor com mensagem
  Helena Caseli
  2010
*/

#include <stdio.h>
#include <stdlib.h>

int main() {
	int x;
	scanf("%d",&x);
	printf("O valor fornecido foi: %d",x);
	return 0;
}
