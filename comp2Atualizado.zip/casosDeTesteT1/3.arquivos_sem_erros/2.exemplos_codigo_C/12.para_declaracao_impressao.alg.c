/*
  Declaracao de variavel do tipo inteiro, comando 'para' com impressao
  Helena Caseli
  2010
*/

#include <stdio.h>
#include <stdlib.h>

int main() {
	int i;
	for (i = 1; i <= 5; i++) {
		printf("%d",i);
		printf("\n");
	}
	return 0;
}
