// Generated from C:\Users\Marcus\Downloads\comp2\T1\src\t1\Lua.g4 by ANTLR 4.2.2
package t1;
import org.antlr.v4.runtime.misc.NotNull;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link LuaParser}.
 */
public interface LuaListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link LuaParser#chamada_atribuicao}.
	 * @param ctx the parse tree
	 */
	void enterChamada_atribuicao(@NotNull LuaParser.Chamada_atribuicaoContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#chamada_atribuicao}.
	 * @param ctx the parse tree
	 */
	void exitChamada_atribuicao(@NotNull LuaParser.Chamada_atribuicaoContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#termo}.
	 * @param ctx the parse tree
	 */
	void enterTermo(@NotNull LuaParser.TermoContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#termo}.
	 * @param ctx the parse tree
	 */
	void exitTermo(@NotNull LuaParser.TermoContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#op_multiplicacao}.
	 * @param ctx the parse tree
	 */
	void enterOp_multiplicacao(@NotNull LuaParser.Op_multiplicacaoContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#op_multiplicacao}.
	 * @param ctx the parse tree
	 */
	void exitOp_multiplicacao(@NotNull LuaParser.Op_multiplicacaoContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#intervalo_opcional}.
	 * @param ctx the parse tree
	 */
	void enterIntervalo_opcional(@NotNull LuaParser.Intervalo_opcionalContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#intervalo_opcional}.
	 * @param ctx the parse tree
	 */
	void exitIntervalo_opcional(@NotNull LuaParser.Intervalo_opcionalContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#parcela_logica}.
	 * @param ctx the parse tree
	 */
	void enterParcela_logica(@NotNull LuaParser.Parcela_logicaContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#parcela_logica}.
	 * @param ctx the parse tree
	 */
	void exitParcela_logica(@NotNull LuaParser.Parcela_logicaContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#programa}.
	 * @param ctx the parse tree
	 */
	void enterPrograma(@NotNull LuaParser.ProgramaContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#programa}.
	 * @param ctx the parse tree
	 */
	void exitPrograma(@NotNull LuaParser.ProgramaContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#outros_termos_logicos}.
	 * @param ctx the parse tree
	 */
	void enterOutros_termos_logicos(@NotNull LuaParser.Outros_termos_logicosContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#outros_termos_logicos}.
	 * @param ctx the parse tree
	 */
	void exitOutros_termos_logicos(@NotNull LuaParser.Outros_termos_logicosContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#ponteiros_opcionais}.
	 * @param ctx the parse tree
	 */
	void enterPonteiros_opcionais(@NotNull LuaParser.Ponteiros_opcionaisContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#ponteiros_opcionais}.
	 * @param ctx the parse tree
	 */
	void exitPonteiros_opcionais(@NotNull LuaParser.Ponteiros_opcionaisContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#tipo_basico}.
	 * @param ctx the parse tree
	 */
	void enterTipo_basico(@NotNull LuaParser.Tipo_basicoContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#tipo_basico}.
	 * @param ctx the parse tree
	 */
	void exitTipo_basico(@NotNull LuaParser.Tipo_basicoContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#fator_logico}.
	 * @param ctx the parse tree
	 */
	void enterFator_logico(@NotNull LuaParser.Fator_logicoContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#fator_logico}.
	 * @param ctx the parse tree
	 */
	void exitFator_logico(@NotNull LuaParser.Fator_logicoContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#op_opcional}.
	 * @param ctx the parse tree
	 */
	void enterOp_opcional(@NotNull LuaParser.Op_opcionalContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#op_opcional}.
	 * @param ctx the parse tree
	 */
	void exitOp_opcional(@NotNull LuaParser.Op_opcionalContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#outros_ident}.
	 * @param ctx the parse tree
	 */
	void enterOutros_ident(@NotNull LuaParser.Outros_identContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#outros_ident}.
	 * @param ctx the parse tree
	 */
	void exitOutros_ident(@NotNull LuaParser.Outros_identContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#outros_fatores}.
	 * @param ctx the parse tree
	 */
	void enterOutros_fatores(@NotNull LuaParser.Outros_fatoresContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#outros_fatores}.
	 * @param ctx the parse tree
	 */
	void exitOutros_fatores(@NotNull LuaParser.Outros_fatoresContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#fator}.
	 * @param ctx the parse tree
	 */
	void enterFator(@NotNull LuaParser.FatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#fator}.
	 * @param ctx the parse tree
	 */
	void exitFator(@NotNull LuaParser.FatorContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#parametro}.
	 * @param ctx the parse tree
	 */
	void enterParametro(@NotNull LuaParser.ParametroContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#parametro}.
	 * @param ctx the parse tree
	 */
	void exitParametro(@NotNull LuaParser.ParametroContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#mais_expressao}.
	 * @param ctx the parse tree
	 */
	void enterMais_expressao(@NotNull LuaParser.Mais_expressaoContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#mais_expressao}.
	 * @param ctx the parse tree
	 */
	void exitMais_expressao(@NotNull LuaParser.Mais_expressaoContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#declaracao_global}.
	 * @param ctx the parse tree
	 */
	void enterDeclaracao_global(@NotNull LuaParser.Declaracao_globalContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#declaracao_global}.
	 * @param ctx the parse tree
	 */
	void exitDeclaracao_global(@NotNull LuaParser.Declaracao_globalContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#parcela_nao_unario}.
	 * @param ctx the parse tree
	 */
	void enterParcela_nao_unario(@NotNull LuaParser.Parcela_nao_unarioContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#parcela_nao_unario}.
	 * @param ctx the parse tree
	 */
	void exitParcela_nao_unario(@NotNull LuaParser.Parcela_nao_unarioContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#mais_var}.
	 * @param ctx the parse tree
	 */
	void enterMais_var(@NotNull LuaParser.Mais_varContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#mais_var}.
	 * @param ctx the parse tree
	 */
	void exitMais_var(@NotNull LuaParser.Mais_varContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#op_nao}.
	 * @param ctx the parse tree
	 */
	void enterOp_nao(@NotNull LuaParser.Op_naoContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#op_nao}.
	 * @param ctx the parse tree
	 */
	void exitOp_nao(@NotNull LuaParser.Op_naoContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#mais_ident}.
	 * @param ctx the parse tree
	 */
	void enterMais_ident(@NotNull LuaParser.Mais_identContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#mais_ident}.
	 * @param ctx the parse tree
	 */
	void exitMais_ident(@NotNull LuaParser.Mais_identContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#cmd}.
	 * @param ctx the parse tree
	 */
	void enterCmd(@NotNull LuaParser.CmdContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#cmd}.
	 * @param ctx the parse tree
	 */
	void exitCmd(@NotNull LuaParser.CmdContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#chamada_partes}.
	 * @param ctx the parse tree
	 */
	void enterChamada_partes(@NotNull LuaParser.Chamada_partesContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#chamada_partes}.
	 * @param ctx the parse tree
	 */
	void exitChamada_partes(@NotNull LuaParser.Chamada_partesContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#registro}.
	 * @param ctx the parse tree
	 */
	void enterRegistro(@NotNull LuaParser.RegistroContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#registro}.
	 * @param ctx the parse tree
	 */
	void exitRegistro(@NotNull LuaParser.RegistroContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#outros_fatores_logicos}.
	 * @param ctx the parse tree
	 */
	void enterOutros_fatores_logicos(@NotNull LuaParser.Outros_fatores_logicosContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#outros_fatores_logicos}.
	 * @param ctx the parse tree
	 */
	void exitOutros_fatores_logicos(@NotNull LuaParser.Outros_fatores_logicosContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#declaracoes_locais}.
	 * @param ctx the parse tree
	 */
	void enterDeclaracoes_locais(@NotNull LuaParser.Declaracoes_locaisContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#declaracoes_locais}.
	 * @param ctx the parse tree
	 */
	void exitDeclaracoes_locais(@NotNull LuaParser.Declaracoes_locaisContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#decl_local}.
	 * @param ctx the parse tree
	 */
	void enterDecl_local(@NotNull LuaParser.Decl_localContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#decl_local}.
	 * @param ctx the parse tree
	 */
	void exitDecl_local(@NotNull LuaParser.Decl_localContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#mais_variaveis}.
	 * @param ctx the parse tree
	 */
	void enterMais_variaveis(@NotNull LuaParser.Mais_variaveisContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#mais_variaveis}.
	 * @param ctx the parse tree
	 */
	void exitMais_variaveis(@NotNull LuaParser.Mais_variaveisContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#expressao}.
	 * @param ctx the parse tree
	 */
	void enterExpressao(@NotNull LuaParser.ExpressaoContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#expressao}.
	 * @param ctx the parse tree
	 */
	void exitExpressao(@NotNull LuaParser.ExpressaoContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#argumentos_opcional}.
	 * @param ctx the parse tree
	 */
	void enterArgumentos_opcional(@NotNull LuaParser.Argumentos_opcionalContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#argumentos_opcional}.
	 * @param ctx the parse tree
	 */
	void exitArgumentos_opcional(@NotNull LuaParser.Argumentos_opcionalContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#var_opcional}.
	 * @param ctx the parse tree
	 */
	void enterVar_opcional(@NotNull LuaParser.Var_opcionalContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#var_opcional}.
	 * @param ctx the parse tree
	 */
	void exitVar_opcional(@NotNull LuaParser.Var_opcionalContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#outros_termos}.
	 * @param ctx the parse tree
	 */
	void enterOutros_termos(@NotNull LuaParser.Outros_termosContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#outros_termos}.
	 * @param ctx the parse tree
	 */
	void exitOutros_termos(@NotNull LuaParser.Outros_termosContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#parcela_unario}.
	 * @param ctx the parse tree
	 */
	void enterParcela_unario(@NotNull LuaParser.Parcela_unarioContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#parcela_unario}.
	 * @param ctx the parse tree
	 */
	void exitParcela_unario(@NotNull LuaParser.Parcela_unarioContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#constantes}.
	 * @param ctx the parse tree
	 */
	void enterConstantes(@NotNull LuaParser.ConstantesContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#constantes}.
	 * @param ctx the parse tree
	 */
	void exitConstantes(@NotNull LuaParser.ConstantesContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#outras_parcelas}.
	 * @param ctx the parse tree
	 */
	void enterOutras_parcelas(@NotNull LuaParser.Outras_parcelasContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#outras_parcelas}.
	 * @param ctx the parse tree
	 */
	void exitOutras_parcelas(@NotNull LuaParser.Outras_parcelasContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#corpo}.
	 * @param ctx the parse tree
	 */
	void enterCorpo(@NotNull LuaParser.CorpoContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#corpo}.
	 * @param ctx the parse tree
	 */
	void exitCorpo(@NotNull LuaParser.CorpoContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#exp_relacional}.
	 * @param ctx the parse tree
	 */
	void enterExp_relacional(@NotNull LuaParser.Exp_relacionalContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#exp_relacional}.
	 * @param ctx the parse tree
	 */
	void exitExp_relacional(@NotNull LuaParser.Exp_relacionalContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#tipo_basico_ident}.
	 * @param ctx the parse tree
	 */
	void enterTipo_basico_ident(@NotNull LuaParser.Tipo_basico_identContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#tipo_basico_ident}.
	 * @param ctx the parse tree
	 */
	void exitTipo_basico_ident(@NotNull LuaParser.Tipo_basico_identContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#variavel}.
	 * @param ctx the parse tree
	 */
	void enterVariavel(@NotNull LuaParser.VariavelContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#variavel}.
	 * @param ctx the parse tree
	 */
	void exitVariavel(@NotNull LuaParser.VariavelContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#decl_local_global}.
	 * @param ctx the parse tree
	 */
	void enterDecl_local_global(@NotNull LuaParser.Decl_local_globalContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#decl_local_global}.
	 * @param ctx the parse tree
	 */
	void exitDecl_local_global(@NotNull LuaParser.Decl_local_globalContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#numero_intervalo}.
	 * @param ctx the parse tree
	 */
	void enterNumero_intervalo(@NotNull LuaParser.Numero_intervaloContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#numero_intervalo}.
	 * @param ctx the parse tree
	 */
	void exitNumero_intervalo(@NotNull LuaParser.Numero_intervaloContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#mais_selecao}.
	 * @param ctx the parse tree
	 */
	void enterMais_selecao(@NotNull LuaParser.Mais_selecaoContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#mais_selecao}.
	 * @param ctx the parse tree
	 */
	void exitMais_selecao(@NotNull LuaParser.Mais_selecaoContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#declaracoes}.
	 * @param ctx the parse tree
	 */
	void enterDeclaracoes(@NotNull LuaParser.DeclaracoesContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#declaracoes}.
	 * @param ctx the parse tree
	 */
	void exitDeclaracoes(@NotNull LuaParser.DeclaracoesContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#mais_parametros}.
	 * @param ctx the parse tree
	 */
	void enterMais_parametros(@NotNull LuaParser.Mais_parametrosContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#mais_parametros}.
	 * @param ctx the parse tree
	 */
	void exitMais_parametros(@NotNull LuaParser.Mais_parametrosContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#tipo_estendido}.
	 * @param ctx the parse tree
	 */
	void enterTipo_estendido(@NotNull LuaParser.Tipo_estendidoContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#tipo_estendido}.
	 * @param ctx the parse tree
	 */
	void exitTipo_estendido(@NotNull LuaParser.Tipo_estendidoContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#parcela}.
	 * @param ctx the parse tree
	 */
	void enterParcela(@NotNull LuaParser.ParcelaContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#parcela}.
	 * @param ctx the parse tree
	 */
	void exitParcela(@NotNull LuaParser.ParcelaContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#comandos}.
	 * @param ctx the parse tree
	 */
	void enterComandos(@NotNull LuaParser.ComandosContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#comandos}.
	 * @param ctx the parse tree
	 */
	void exitComandos(@NotNull LuaParser.ComandosContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#op_unario}.
	 * @param ctx the parse tree
	 */
	void enterOp_unario(@NotNull LuaParser.Op_unarioContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#op_unario}.
	 * @param ctx the parse tree
	 */
	void exitOp_unario(@NotNull LuaParser.Op_unarioContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#exp_aritmetica}.
	 * @param ctx the parse tree
	 */
	void enterExp_aritmetica(@NotNull LuaParser.Exp_aritmeticaContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#exp_aritmetica}.
	 * @param ctx the parse tree
	 */
	void exitExp_aritmetica(@NotNull LuaParser.Exp_aritmeticaContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#valor_constante}.
	 * @param ctx the parse tree
	 */
	void enterValor_constante(@NotNull LuaParser.Valor_constanteContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#valor_constante}.
	 * @param ctx the parse tree
	 */
	void exitValor_constante(@NotNull LuaParser.Valor_constanteContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#mais_constantes}.
	 * @param ctx the parse tree
	 */
	void enterMais_constantes(@NotNull LuaParser.Mais_constantesContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#mais_constantes}.
	 * @param ctx the parse tree
	 */
	void exitMais_constantes(@NotNull LuaParser.Mais_constantesContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#op_adicao}.
	 * @param ctx the parse tree
	 */
	void enterOp_adicao(@NotNull LuaParser.Op_adicaoContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#op_adicao}.
	 * @param ctx the parse tree
	 */
	void exitOp_adicao(@NotNull LuaParser.Op_adicaoContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#dimensao}.
	 * @param ctx the parse tree
	 */
	void enterDimensao(@NotNull LuaParser.DimensaoContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#dimensao}.
	 * @param ctx the parse tree
	 */
	void exitDimensao(@NotNull LuaParser.DimensaoContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#selecao}.
	 * @param ctx the parse tree
	 */
	void enterSelecao(@NotNull LuaParser.SelecaoContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#selecao}.
	 * @param ctx the parse tree
	 */
	void exitSelecao(@NotNull LuaParser.SelecaoContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#identificador}.
	 * @param ctx the parse tree
	 */
	void enterIdentificador(@NotNull LuaParser.IdentificadorContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#identificador}.
	 * @param ctx the parse tree
	 */
	void exitIdentificador(@NotNull LuaParser.IdentificadorContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#op_relacional}.
	 * @param ctx the parse tree
	 */
	void enterOp_relacional(@NotNull LuaParser.Op_relacionalContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#op_relacional}.
	 * @param ctx the parse tree
	 */
	void exitOp_relacional(@NotNull LuaParser.Op_relacionalContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#tipo}.
	 * @param ctx the parse tree
	 */
	void enterTipo(@NotNull LuaParser.TipoContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#tipo}.
	 * @param ctx the parse tree
	 */
	void exitTipo(@NotNull LuaParser.TipoContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#senao_opcional}.
	 * @param ctx the parse tree
	 */
	void enterSenao_opcional(@NotNull LuaParser.Senao_opcionalContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#senao_opcional}.
	 * @param ctx the parse tree
	 */
	void exitSenao_opcional(@NotNull LuaParser.Senao_opcionalContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#termo_logico}.
	 * @param ctx the parse tree
	 */
	void enterTermo_logico(@NotNull LuaParser.Termo_logicoContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#termo_logico}.
	 * @param ctx the parse tree
	 */
	void exitTermo_logico(@NotNull LuaParser.Termo_logicoContext ctx);

	/**
	 * Enter a parse tree produced by {@link LuaParser#parametros_opcional}.
	 * @param ctx the parse tree
	 */
	void enterParametros_opcional(@NotNull LuaParser.Parametros_opcionalContext ctx);
	/**
	 * Exit a parse tree produced by {@link LuaParser#parametros_opcional}.
	 * @param ctx the parse tree
	 */
	void exitParametros_opcional(@NotNull LuaParser.Parametros_opcionalContext ctx);
}