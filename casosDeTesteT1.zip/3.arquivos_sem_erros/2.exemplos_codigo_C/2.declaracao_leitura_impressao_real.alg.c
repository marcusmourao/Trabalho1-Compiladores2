/*
  Declaracao de uma variavel do tipo real, leitura e impressao de seu valor
  Helena Caseli
  2010
*/

#include <stdio.h>
#include <stdlib.h>

int main() {
	float x;
	scanf("%f",&x);
	printf("%f",x);
	return 0;
}
