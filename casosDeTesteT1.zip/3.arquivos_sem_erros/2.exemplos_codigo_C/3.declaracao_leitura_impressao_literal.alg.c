/*
  Declaracao de uma variavel do tipo literal, leitura e impressao de seu valor
  Helena Caseli
  2010
*/

#include <stdio.h>
#include <stdlib.h>

int main() {
	char x[80];
	gets(x);
	printf("%s",x);
	return 0;
}
